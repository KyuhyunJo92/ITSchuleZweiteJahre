﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Xml;
using System.Windows;
using System.ComponentModel;
using System.Windows.Controls;
using Newtonsoft.Json;
using System.Windows.Documents;
using PA_vorbereitung.Model;
using PA_vorbereitung.Model.WetterStruct;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PA_vorbereitung.ViewModel
{
	class WetterAPIViewModel : INotifyPropertyChanged
	{
		public FlowDocument FlowDoc { get; set; }
		const string targetURL = "https://dwd.api.proxy.bund.dev/v30/stationOverviewExtended?stationIds=10738";
		
		//constructor
		public WetterAPIViewModel()
		{
			WetterDataJson= string.Empty;
		}
		string WetterDataJson;
		private void ReadAPI()
		{
			//prevent ssl/tls version error
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

			WebClient client = new WebClient();
			try
			{
				string url = targetURL;
				WetterDataJson = client.DownloadString(url);
				//StationID : 10738 ist Stuttgart. Ein Nummer kann nicht ein Objektname sein.
				//Aufgrund muss man die name nach einem Charakter wechsel.

				//Sie können eine Switch-Case-Anweisung verwenden, 
				//um Wetterbeobachtungen in anderen Regionen abzudecken, 
				//oder Sie können eine const-String-Klasse implementieren, 
				//die die IDs aller Wetterstationen speichert.
				WetterDataJson = WetterDataJson.Replace("10738", "Stuttgart");
			}
			catch (Exception exc)
			{
				MessageBox.Show(exc.Message);
			}
		}

		public void DisplayWeatherData()
		{
			ReadAPI();
			//Speichert Werte in implementierten Datenstrukturtypklassen.
			//Die entsprechende Datenstrukturtypklasse muss einem JSON-Schlüssel entsprechen 
			//und als Datentyp implementiert werden, der groß genug ist, um den Wert zu speichern.
			RootObj root = JsonConvert.DeserializeObject<RootObj>(WetterDataJson);

			//constuct arbeit für RichTextBox
			structrierenFlowDoc(root);
		}
		public void structrierenFlowDoc (RootObj root)
		{
			Paragraph headerLine = new Paragraph();

			Run Ort = new Run(root.Stuttgart.forecast1.stationId);
			headerLine.Inlines.Add(Ort);
			headerLine.Inlines.Add(" Vorsage");
			headerLine.Inlines.Add("\n");
			headerLine.FontSize = 40;
			headerLine.FontWeight = FontWeights.Bold;
			FlowDoc.Blocks.Add(headerLine);

			Paragraph paragraphs = new Paragraph();
			Run runParags =
				new Run("Day_Date\tMin_Temp\tMax_Temp\tIcon\t\tPrepitation\tWind_Speed\tWind_Direction\tSunshine\t\t\tSunrise\t\tSunset\t\tMoonrise\t\tMoonset\t\tMoon_Phase");
			paragraphs.Inlines.Add(runParags);
			paragraphs.FontStyle = FontStyles.Italic;
			FlowDoc.Blocks.Add(paragraphs);
			
			foreach(Day el in root.Stuttgart.days)
			{
				Paragraph p = new Paragraph();
				Run dayDate = new Run(el.dayDate.ToString("dd-MM-yyyy"));
				p.Inlines.Add(dayDate);
				p.Inlines.Add("\t");

				double minTemp = el.temperatureMin / 10;
				Run temperatureMin = new Run(minTemp.ToString());
				temperatureMin.Foreground = Brushes.Blue;
				p.Inlines.Add(temperatureMin);
				p.Inlines.Add("°C\t\t");

				double maxTemp = el.temperatureMax / 10;
				Run temperatureMax = new Run(maxTemp.ToString());
				temperatureMax.Foreground = Brushes.Red;
				p.Inlines.Add(temperatureMax);
				p.Inlines.Add("°C\t\t");

				Image wetterImage = new Image();
				try{wetterImage.Source = new BitmapImage(new Uri(StaticFunctions.IconConvertURL(el.icon)));}
				catch (FileNotFoundException){}
				catch (Exception) { }
				wetterImage.Width = 50;
				wetterImage.Height = 50;
				InlineUIContainer wetterImgContainer = new InlineUIContainer(wetterImage);
				p.Inlines.Add(wetterImgContainer);
				p.Inlines.Add("\t");

				Run precipitation = new Run(el.precipitation.ToString());
				p.Inlines.Add(precipitation);
				p.Inlines.Add("%\t\t");
				
				Run windSpeed = new Run(el.windSpeed.ToString());
				p.Inlines.Add(windSpeed);
				p.Inlines.Add(" Km/h   \t");

				string stringWindDirection = StaticFunctions.WindDirectionConvert(el.windDirection);
				Run windDirection = new Run(stringWindDirection);
				p.Inlines.Add(windDirection);
				p.Inlines.Add("\t");

				string stringSunshine = StaticFunctions.SunshineConver(el.sunshine);
				Run sunshine		 = new Run(stringSunshine);
				p.Inlines.Add(sunshine);
				p.Inlines.Add("\t\t");

				DateTimeOffset DateTimeSunrise = DateTimeOffset.FromUnixTimeMilliseconds(el.sunrise);
				Run sunrise			 = new Run($"{DateTimeSunrise.Hour}Uhr {DateTimeSunrise.Minute}    ");
				p.Inlines.Add(sunrise);
				p.Inlines.Add("\t");

				DateTimeOffset DateTimeSunset = DateTimeOffset.FromUnixTimeMilliseconds(el.sunset);
				Run sunset			 = new Run($"{DateTimeSunset.Hour}Uhr {DateTimeSunset.Minute}    ");
				p.Inlines.Add(sunset);
				p.Inlines.Add("\t");

				DateTimeOffset DateTimeMoonrise = DateTimeOffset.FromUnixTimeMilliseconds(el.moonrise);
				Run moonrise		 = new Run($"{DateTimeMoonrise.Hour}Uhr {DateTimeMoonrise.Minute}    ");
				p.Inlines.Add(moonrise);
				p.Inlines.Add("\t");

				DateTimeOffset DateTimeMoonset = DateTimeOffset.FromUnixTimeMilliseconds(el.moonset);
				Run moonset			 = new Run($"{DateTimeMoonset.Hour}Uhr {DateTimeMoonset.Minute}    ");
				p.Inlines.Add(moonset);
				p.Inlines.Add("\t");
			
				Image moonphasesImage = new Image();
				try { moonphasesImage.Source = new BitmapImage(new Uri(StaticFunctions.MoonPhasesURL(el.moonPhase))); }
				catch (FileNotFoundException) { }
				catch (Exception) { }
				moonphasesImage.Width = 50;
				moonphasesImage.Height = 50;
				InlineUIContainer moonphasesImgContainer = new InlineUIContainer(moonphasesImage);
				p.Inlines.Add(moonphasesImgContainer);
				p.Inlines.Add("\t");
				
				p.Inlines.Add("\n");
				FlowDoc.Blocks.Add(p);
			}
		}

		
		// INotifyPropertyChanged implementierung
		public event PropertyChangedEventHandler PropertyChanged;

		protected virtual void OnPropertyChanged(string propertyName)
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
	

		
