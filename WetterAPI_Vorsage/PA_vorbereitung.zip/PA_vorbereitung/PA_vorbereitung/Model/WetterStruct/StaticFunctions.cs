﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Windows.Controls;
using System.Windows.Media.Imaging;


namespace PA_vorbereitung.Model.WetterStruct
{
	public static class StaticFunctions
	{
		public static string IconConvertURL(int iconNum)
		{
			switch (iconNum)
			{
				case 1:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Sonne.png";
				case 2:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Sonne, leicht bewölkt.png";
				case 3:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Sonne, leicht bewölkt.png";					
				case 4:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Wolken.png";
				case 5:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Nebel.png";
				case 6:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Nebel.png";
				case 7:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Regen.png";
				case 8:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Regen.png";
				case 9:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Starker Regen.png";
				case 10:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Regen.png";
				case 11:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Starker Regen.png";
				case 12:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Schneefall.png";
				case 13:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Schneefall.png";
				case 14:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Schneefall.png";
				case 15:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Schneefall.png";
				case 16:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Schneefall.png";
				case 17:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Wolkel, (Hagel).png";
				case 18:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Sonne, leicht bewölkt.png";
				case 19:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Sonne, leichter Regen.png";
				case 20:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Schneefall.png";
				case 21:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Schneefall.png";
				case 22:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Schneefall.png";
				case 23:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Schneefall.png";
				case 24:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Wolkel, (Hagel).png";
				case 25:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Wolkel, (Hagel).png";
				case 26:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Gewitter.png";
				case 27:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Gewitter.png";
				case 28:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Gewitter.png";
				case 29:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Gewitter.png";
				case 30:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Gewitter.png";
				case 31:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/WetterIcons/Wind.png";
				default:
					return "null";
			}
		}
		public static string MoonPhasesURL(int MoonPhaseNum)
		{
			switch(MoonPhaseNum)
			{
				case 0:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/MondPhaseIcons/Zunehmender_Sichelmond.png";
				case 1:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/MondPhaseIcons/Zunehmender_Halbmond.png";
				case 2:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/MondPhaseIcons/Zunehmender_Dreiviertelmond.png";
				case 3:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/MondPhaseIcons/Vollmond.png";
				case 4:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/MondPhaseIcons/Abnehmender_Dreiviertelmond.png";
				case 5:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/MondPhaseIcons/Abnehmender_Halbmond.png";
				case 6:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/MondPhaseIcons/Abnehmender_Sichelmond.png";
				case 7:
					return "pack://application:,,,/PA_vorbereitung;component/Model/WetterStruct/MondPhaseIcons/Neumond.png";
				default:
					return "null";
			}
		}
		public static string WindDirectionConvert(int WindDegree)
		{
			if (WindDegree >= 0 && WindDegree < 112.5 || WindDegree >= 3487.5 && WindDegree < 3600) { return "Norden         "; }
			else if (WindDegree >= 112.5 && WindDegree < 33.75) { return   "Nordnordosten  "; }
			else if (WindDegree >= 337.5 && WindDegree < 562.5) { return   "Nordosten      "; }
			else if (WindDegree >= 562.5 && WindDegree < 787.5) { return   "Ostnordosten   "; }
			else if (WindDegree >= 787.5 && WindDegree < 1012.5) { return  "Osten          "; }
			else if (WindDegree >= 1012.5 && WindDegree < 1237.5) { return "OstSüdosten    "; }
			else if (WindDegree >= 1237.5 && WindDegree < 1462.5) { return "Südosten       "; }
			else if (WindDegree >= 1462.5 && WindDegree < 1687.5) { return "Südsüdosten    "; }
			else if (WindDegree >= 1687.5 && WindDegree < 1912.5) { return "Süden          "; }
			else if (WindDegree >= 1912.5 && WindDegree < 2137.5) { return "Südsüdwesten   "; }
			else if (WindDegree >= 2137.5 && WindDegree < 2362.5) { return "Südwesten      "; }
			else if (WindDegree >= 2362.5 && WindDegree < 2587.5) { return "Westsüdwesten  "; }
			else if (WindDegree >= 2587.5 && WindDegree < 2812.5) { return "Westen         "; }
			else if (WindDegree >= 2812.5 && WindDegree < 3037.5) { return "Westnordwesten "; }
			else if (WindDegree >= 3037.5 && WindDegree < 3262.5) { return "Nordwesten     "; }
			else if (WindDegree >= 3262.5 && WindDegree < 3487.5) { return "Nordnordwesten "; }
			else { return "null           "; }
			
		}
		public static string SunshineConver(int sunshine)
		{
			int lux = sunshine / 10;
			if (sunshine > 0 && sunshine <= 2000)
			{
				return string.Format("Dunkel, {0}Lux   ", lux.ToString());
			}
			if (sunshine > 2000 && sunshine <= 5000)
			{
				return string.Format("Wenig, {0}Lux    ", lux.ToString());
			}
			else if (sunshine > 5000 && sunshine <= 10000)
			{
				return string.Format("Geeignet, {0}Lux ", lux.ToString());
			}
			else if (sunshine > 10000 && sunshine <= 20000)
			{
				return string.Format("Starke, {0}Lux   ", lux.ToString());
			}
			else if (sunshine > 20000)
			{
				return string.Format("Gefahr, {0}Lux   ", lux.ToString());
			}
			else return             "null             ";
		}
	}
}
