﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PA_vorbereitung.Model.WetterStruct
{
	public class RootObj
	{
		public Station Stuttgart { get; set; }
	}
	public class Station
	{
		public ForeCast1 forecast1 { get; set; }
		public ForeCast2 forecast2 { get; set; }
		public string forecastStart { get; set; }
		public List<Day> days { get; set; }
		public List<Warning> warnings { get; set; }
		public string threeHourSummaries { get; set; }
	}

	public class ForeCast1
	{
		public string stationId { get; set; }
		public long start { get; set; }
		public long timeStep { get; set; }
		public List<int> temperature { get; set; }
		public List<int> temperatureStd { get; set; }
		public string windSpeed { get; set; }
		public string windDirection { get; set; }
		public string windGust { get; set; }
		public List<int> icon { get; set; }
		public List<int> precipitationTotal { get; set; }
		public List<int> dewPoint2m { get; set; }
		public List<int> surfacePressure { get; set; }
		public List<int> humidity { get; set; }
		public List<bool> isDay { get; set; }
		public string PrecipitationProbablity { get; set; }
		public string PrecipitationProbablityIndex { get; set; }
	}

	public class ForeCast2
	{
		public string stationId { get; set; }
		public long start { get; set; }
		public long timeStep { get; set; }
		public List<int> temperature { get; set; }
		public List<int> temperatureStd { get; set; }
		public string windSpeed { get; set; }
		public string windDirection { get; set; }
		public string windGust { get; set; }
		public List<int> icon { get; set; }
		public List<int> precipitationTotal { get; set; }
		public List<int> dewPoint2m { get; set; }
		public List<int> surfacePressure { get; set; }
		public List<int> humidity { get; set; }
		public List<bool> isDay { get; set; }
		public string PrecipitationProbablity { get; set; }
		public string PrecipitationProbablityIndex { get; set; }
	}

	public class Day
	{
		public string stationId { get; set; }
		public DateTime dayDate { get; set; }
		public int temperatureMin { get; set; }
		public int temperatureMax { get; set; }
		public int icon { get; set; }
		public string icon1 { get; set; }
		public string icon2 { get; set; }
		public int precipitation { get; set; }
		public int windSpeed { get; set; }
		public int windGust { get; set; }
		public int windDirection { get; set; }
		public int sunshine { get; set; }
		public long sunrise { get; set; }
		public long sunset { get; set; }
		public long moonrise { get; set; }
		public long moonset { get; set; }
		public int moonPhase { get; set; }
	}

	public class Warning
	{
	}

}
