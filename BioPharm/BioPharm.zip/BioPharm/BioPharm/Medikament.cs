﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BioPharm
{
    class Medikament
    {
        private string haltbarkeitsdatum;
        private string name;
        private string wirksamkeit;
        private long id;
        private Medikamentenform.Medikamentenform arzneiForm;

        public Medikament(string haltbarkeitsdatum, string name, string wirksamkeit, Medikamentenform.Medikamentenform formInfos )
        {
            this.arzneiForm = formInfos;
            this.haltbarkeitsdatum = haltbarkeitsdatum;
            this.name = name;
            this.wirksamkeit = wirksamkeit;
        }
    }
}
