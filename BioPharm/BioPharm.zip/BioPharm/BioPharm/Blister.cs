﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BioPharm
{
    class Blister
    {
        private Medikament[] medikamente;
        private int anzahlMulden;
        private int anzahlReihen;
        private int anzahlSpalten;
        private int anzahlMedikamente;
        private bool[,] bestandInfo;
        long id;

        public Blister(int anzahlReihen, int anzahlSpalten, long id, Medikament[] produzierteMedikamente)
        {
            anzahlMulden = anzahlReihen * anzahlSpalten;
            medikamente = new Medikament[anzahlMulden]();
        }
        public bool entnehmen(int indexReihe, int indexSpalte) { return false; }//this must be handled.
        public void druckeBestandInfo() { }
    }
}
