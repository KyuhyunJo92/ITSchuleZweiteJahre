﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BioPharm.Medikamentenform
{
    class Kapselform : Medikamentenform
    {
        private double gelMengeInG;

        public Kapselform(double gewichtInG, double laengeInMm, double breiteInMm, long id, double gelMengeInG) : base(gewichtInG, laengeInMm, breiteInMm, id, gelMengeInG) { }
        override public string wirkstofffreisetzung()
        {
            return "Ein wird freigesetzt.";
        }
    }
}
