﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BioPharm.Medikamentenform
{
    class Tablettenform : Medikamentenform
    {
        private double pulverKoernungInUm;

        public Tablettenform(double gewichtInG, double laengeInMm, double breiteInMm, long id, double gelMengeInG)
        : base(gewichtInG, laengeInMm, breiteInMm, id, gelMengeInG) { }
        override public string wirkstofffreisetzung()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Freisetzung des Wirkstoffes durch Zersetzung der Tablette. Pulverkoernung in Mikrometer:{0} ");
            sb.Append(pulverKoernungInUm.ToString());
            string ergebnis = sb.ToString();
            return ergebnis;
        }
    }


}
