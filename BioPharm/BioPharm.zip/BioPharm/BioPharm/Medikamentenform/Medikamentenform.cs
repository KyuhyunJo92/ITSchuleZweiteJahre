﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BioPharm.Medikamentenform
{
    abstract class Medikamentenform
    {
        //attribute
        private double gewichtInG;
        private double lanengeInMm;
        private double breiteInMm;
        private long id;
        

        //method
        public Medikamentenform(double gewichtInG, double laengeInMm, double breiteInMm, long id, double gelMengeInG) { }
        abstract public string wirkstofffreisetzung();
    }
    
    
}
