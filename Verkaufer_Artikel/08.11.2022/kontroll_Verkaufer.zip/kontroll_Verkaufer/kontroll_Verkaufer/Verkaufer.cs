﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kontroll_Verkaufer
{
    class Verkaufer
    {
        private int VID;
        private List<Artikel> artikels = new List<Artikel>();
        public Verkaufer(int vid)
        {
            VID = vid;
        }
        public double getPreis(int i) { return artikels[i].getPreis(); }
        public void setPreis(int i, double p) { artikels[i].setPreis(p); }
        public void kaufen(int i, int b) { artikels[i].kaufen(b); }
        public void rabat(int s, int d) 
        {
            foreach(Artikel a in artikels)
            {
                if(a.getBestand()>s)
                {
                    a.setPreis(a.getPreis() * (100 - d) / 100);
                }
            }
        }
        public void addArtikel(Artikel a) { artikels.Add(a); }
        public override string ToString()
        {
            string strResult;
            StringBuilder sb = new StringBuilder();
            sb.Append(VID.ToString());
            sb.Append(";");
            foreach(Artikel a in artikels)
            {
                sb.Append(a.ToString());
            }
            strResult = sb.ToString();
            return strResult;
        }

    }
    
}
