﻿using System;

namespace kontroll_Verkaufer
{
    class Program
    {
        static void Main(string[] args)
        {
            Artikel hosen = new Artikel();
            hosen.setName("Hosen");
            hosen.setCode("ho");
            hosen.setBestand(300);
            hosen.setPreis(120);
            Verkaufer verkaufer1 = new Verkaufer(1);
            verkaufer1.addArtikel(hosen);

            Console.WriteLine(verkaufer1.ToString());
        }
    }
}
