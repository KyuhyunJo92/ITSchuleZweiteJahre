﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kontroll_Verkaufer
{
    class Artikel
    {
        private string name;
        private string code;
        private int bestand;
        private double preis;

        public Artikel() { }
        public void setName(string n) { name = n; }
        public string getName() { return name; }
        public void setCode(string c) { code = c; }
        public string getCode() { return code; }
        public void setBestand(int s) { bestand = s; }
        public int getBestand() { return bestand; }
        public void setPreis(double p) { preis = p; }
        public double getPreis() { return preis; }
        public void kaufen(int b) { bestand = bestand + b; }
        public override string ToString()
        {
            string strReturn;
            StringBuilder sb = new StringBuilder();
            sb.Append(getName());
            sb.Append(";");
            sb.Append(getCode());
            sb.Append(";");
            sb.Append(getBestand());
            sb.Append(";");
            sb.Append(getPreis());
            sb.Append(";");
            strReturn = sb.ToString();
            return strReturn;
        }

    }
}
