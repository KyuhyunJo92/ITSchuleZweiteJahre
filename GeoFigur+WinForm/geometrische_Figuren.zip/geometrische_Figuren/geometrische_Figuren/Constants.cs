﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace geometrische_Figuren
{
    class Constants
    {
        public const double pi = 3.141592;
        public const double goldenRate = 1.1618;
    }
}